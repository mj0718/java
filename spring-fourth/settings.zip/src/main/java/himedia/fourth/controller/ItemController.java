package himedia.fourth.controller;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import himedia.fourth.domain.Item;
import himedia.fourth.repository.ItemRepository;
import lombok.extern.slf4j.Slf4j;

@Controller
@Slf4j
public class ItemController {
	private final ItemRepository repository;
	
	public ItemController(ItemRepository repository) {
		this.repository = repository;
	}
	
	@GetMapping("/store/items")
	public String items(Model model) {
		List<Item> items = repository.findAll();
		model.addAttribute("items", items);
		
		return "store/items";
	}
	
	@GetMapping("/store/items/{itemId}")
	public String item(@PathVariable Long itemId, Model model) {
		log.info("itemId >> {}", itemId);
		Item item = repository.findById(itemId).get();
		model.addAttribute("item", item);
		return "store/item";
	}
}
