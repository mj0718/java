package himedia.fourth;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringFourthApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringFourthApplication.class, args);
	}

}
