package p230118;

public class TypeEx02 {
	public static void main(String[] args) {
	
		//반드시 문자로 시작 (숫자로 시작하면 에러)
	    //int 2num; //Error
	    //띄어쓰기 불가
	    //int num two; //Error
	    //기호는 _만 가능
	    //int num!two; //Error
		
	}
}
