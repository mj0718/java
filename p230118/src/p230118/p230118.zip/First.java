package p230118;

public class First {
	
	public static void main(String[] args) {
		System.out.print("Hello!");
		System.out.println("Hi");
		System.out.println(5);
		System.out.println('a');
		System.out.println("a");
	}

}
